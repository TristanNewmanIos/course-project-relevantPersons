import React, { PureComponent } from 'react';
import classes from './App.css';
import Person from '/Users/Tristan/Desktop/directory/Udemy/React/complete-react-guide/src/Components/Persons/Person/Person';
import Persons from '../Components/Persons/Persons';
import Cockpit from '../Components/Cockpit/Cockpit';
import Aux from '../Components/HOC/Aux';
import withClass from '../Components/HOC/withClass';

export const AuthContext = React.createContext(false);

class App extends PureComponent {

  constructor(props) {
    super(props);
    console.log('[App.js] Inside Constructor', props);
  }

  componentWillMount(){
    console.log('[App.js] Inside componentWillMount()');
}

  componentDidMount(){
    console.log('[App.js] Inside componentDidMount()');
  }

  // shouldComponentUpdate(nextProps,nextState){
  //   console.log('[UPDATE App.js] Inside shouldComponentUpdate', nextProps, nextState);
  //   return nextState.persons != this.state.persons ||
  //   nextState.showPersons != this.state.showPersons;
  // }

  componentWillUpdate(nextProps, nextState){
    console.log('[UPDATE App.js] Inside componentWillUpdate()', nextProps, nextState);
  }

  static getDerivedStateFromProps(nextProps, prevState){
    console.log('[UPDATE App.js] Inside getDerivedStateFromProps()', nextProps, prevState);
    return prevState;
  }

  getSnapshotBeforeUpdate(){
      console.log('[UPDATE App.js] Inside getSnapshotBeforeUpdate()');
  }

  componentDidUpdate(){
    console.log('[UPDATE App.js] Inside componentDidUpdate()', this.props, this.state);
  }

  state={
    persons: [
      {id: 'obm72', name: "Tristan", age:"28"},
      {id: 'ou70', name: "Weronika", age:"22"},
      {id: 'ouged', name: "Przemek", age:"28"}
    ],
    showPersons: false,
    toggleClicked: 0,
    authenticated: false
  }

  switchNameHandler = (newName) => {
    // this.state.persons[0].name= "Max";
    this.setState({
      persons: [
        {name: newName, age:"28"},
        {name: "Akinorew", age:"22"},
        {name: "Kemeyzrp", age:"28"}
      ]});

  }

  namedChangedHandler = (event, id) => {
    const personIndex= this.state.persons.findIndex(p =>{
      return p.id === id;
    })

//... is the spread operator
    const person= {
      ...this.state.persons[personIndex]
    };

    person.name= event.target.value;

    const persons = [...this.state.persons];
    persons[personIndex]= person;

    this.setState({
      persons: persons
    });
  }

  togglePersonsHandler= ()=>{
    const doesShow = this.state.showPersons;
    this.setState((prevState, props) =>{
      return {
        showPersons: !doesShow,
        toggleClicked: prevState.toggleClicked+1}
    })
  }

  deletePersonHandler= (personIndex) =>{
    const persons= this.state.persons.slice();
    persons.splice(personIndex, 1)
    this.setState({persons: persons})
  }

  loginHandler = () => {
    this.setState(
      {authenticated: true}
    );
  }

  render() {
    console.log('[App.js] Inside render');

    let persons= null;

    if (this.state.showPersons) {

      persons = (
          <Persons
            persons={this.state.persons}
            clicked={this.deletePersonHandler}
            changed={this.namedChangedHandler}/>
      );

    }

    return (
<Aux>
      <button onClick={()=>{this.setState({showPersons: true})}}>Show Persons</button>
      <Cockpit
        appTitle={this.props.title}
        showPersons= {this.state.showPersons}
        persons={this.state.persons}
        clicked={this.togglePersonsHandler}
        login={this.loginHandler}/>
        <AuthContext.Provider value={this.state.authenticated}>
          {persons}
        </AuthContext.Provider>
</Aux>
    );
  }
}

export default withClass(App, classes.App);
